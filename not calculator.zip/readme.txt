Setup instructions:

Extract the folder's contents anywhere (make sure they're all in the same folder).
Download and install debugview: https://docs.microsoft.com/en-us/sysinternals/downloads/debugview
Run the ahk script that you need (either 1 eye or 2 eye).



Use instructions (assuming you already know how to get the perfect travel angle, if you don't, then read pages 5 and 6 of this doc: https://docs.google.com/document/d/1JTMOIiS-Hl6_giEB0IQ5ki7UV-gvUXnNmoxhYoSgEAA/edit):

Open up DebugView on a second monitor (the program that you installed).
Once you get your angle and f3 c, pause and press Ctrl P.
Follow the instructions in the GUI and wait for DebugView to show what you need.
If you're doing 1 eye, then the first location that shows up is the closest.
If you're doing 2 eye, then after it's done "computing" the numbers for second eye, it'll give you a final destination chunk to go to.
